export class AddOnOptions{
    
    name:string='';
    IsSelected:number=0;
}