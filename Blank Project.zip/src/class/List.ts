export class List{
    id:number=0;
    Name:string='';
    Email:string='';
}